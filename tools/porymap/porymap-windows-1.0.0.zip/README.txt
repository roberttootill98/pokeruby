Version: 1.0.0
Date: October 26th, 2018

This version of porymap is compatible with pokeruby and pokeemerald as of the following commit hashes:
pokeruby: 9d62ad060b05848a0cad1f09881c3863596455fd
pokeemerald: 2778e9ad3dc249eb4cce84be3ac1dfcc7ab850d5

This is the initial release, and there are some known bugs and crashes.  Please report any issues on GitHub: https://github.com/huderlem/porymap/issues


